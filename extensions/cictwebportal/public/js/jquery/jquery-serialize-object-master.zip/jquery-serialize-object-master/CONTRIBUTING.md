Contributing
============

All pull requests **must** be backed by tests or they will be rejected.

Once you have finished your changes, build the new plugin:

```sh
$ npm run-script build
```

**Do not** bump the version. I will handle versioning.
